import { Component, signal, OnInit, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Footer } from './components/footer/footer';
import { ColorLabChallenge } from './components/color-lab-challenge/color-lab-challenge';


interface Slide {
  id: string;
  title: string;
}

@Component({
  selector: 'app-root',
  imports: [
    CommonModule, Footer,  ColorLabChallenge
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit {
  protected currentSlideId = signal<string>('intro');

  // Lista de slides de la presentación
  protected readonly slides: Slide[] = [
    { id: 'juego-colores', title: 'Laboratorio de Mezcla de Colores' },
  ];

  constructor() {
    // Sync hash with currentSlideId
    effect(() => {
      const slideId = this.currentSlideId();
      if (window.location.hash !== `#${slideId}`) {
        window.location.hash = slideId;
      }
    });
  }

  ngOnInit() {
    // Initialize from hash or default to first slide
    const hash = window.location.hash.slice(1);
    const slideExists = this.slides.some(s => s.id === hash);
    if (hash && slideExists) {
      this.currentSlideId.set(hash);
    } else {
      window.location.hash = this.slides[0].id;
    }

    // Listen to hash changes
    window.addEventListener('hashchange', () => {
      const newHash = window.location.hash.slice(1);
      const slideExists = this.slides.some(s => s.id === newHash);
      if (slideExists && newHash !== this.currentSlideId()) {
        this.currentSlideId.set(newHash);
      }
    });
  }

  protected getCurrentSlideIndex(): number {
    return this.slides.findIndex(s => s.id === this.currentSlideId());
  }

  protected nextSlide() {
    const currentIndex = this.getCurrentSlideIndex();
    if (currentIndex < this.slides.length - 1) {
      this.currentSlideId.set(this.slides[currentIndex + 1].id);
    }
  }

  protected prevSlide() {
    const currentIndex = this.getCurrentSlideIndex();
    if (currentIndex > 0) {
      this.currentSlideId.set(this.slides[currentIndex - 1].id);
    }
  }

  protected goToSlide(slideId: string) {
    this.currentSlideId.set(slideId);
  }

  protected isCurrentSlide(slideId: string): boolean {
    return this.currentSlideId() === slideId;
  }

  getCurrentYear(): number {
    return new Date().getFullYear();
  }

  getCurrentMonth(): string {
    const months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    return months[new Date().getMonth()];
  }
}
